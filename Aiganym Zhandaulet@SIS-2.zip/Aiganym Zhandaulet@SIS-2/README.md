# Character device driver
To load the character device, write "sh project.load" after "make" command. To unload call "sh project.unload".

# Useful links: 
- printk formats:
	- https://www.kernel.org/doc/Documentation/printk-formats.txt
	- https://lore.kernel.org/patchwork/patch/960923/
- error codes:
	- http://www-numi.fnal.gov/offline_software/srt_public_context/WebDocs/Errors/unix_system_errors.html
